﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DM1TIMBERT
{
    class Program
    {
        static void Main(string[] args)
        {
            //Déclaration de la variable
            string entree;
            char lettre;
            
            //Première question
            Console.WriteLine("Que veut dire SIO ?");
            Console.WriteLine("a : Services Informatiques aux Organisations ; b : Services Industriels aux Organisations");
            entree = Console.ReadLine();
            lettre = char.Parse(entree);

            //Réponse première question
            switch (lettre)
            {
                case 'a':
                    Console.WriteLine("Bravo, c'est la bonne réponse : +2 points");
                    break;
                default: Console.WriteLine("Dommage, la bonne réponse était a : -1 point");
                    break;
            }

            //Deuxième question
            Console.WriteLine("\nCombien d'option le BTS SIO dispose-t-il ?");
            Console.WriteLine("a : 3 Options ; b : 2 Options ");
            entree = Console.ReadLine();
            lettre = char.Parse(entree);

            //Réponse deuxième question
            switch (lettre)
            {
                case 'b':
                    Console.WriteLine("Bravo, c'est la bonne réponse : +2 points");
                    break;
                default:
                    Console.WriteLine("Dommage, la bonne réponse était b : -1 point");
                    break;
            }

            //Troisième question
            Console.WriteLine("\nA chaque moment choisit-on son option ?");
            Console.WriteLine("a : A la fin du premier semestre ; b : A la fin du deuxième semestre ");
            entree = Console.ReadLine();
            lettre = char.Parse(entree);

            //Réponse troisième question
            switch (lettre)
            {
                case 'a':
                    Console.WriteLine("Bravo, c'est la bonne réponse : +2 points");
                    break;
                default:
                    Console.WriteLine("Dommage, la bonne réponse était a : -1 point");
                    break;
            }
            
            //Quatrième question
            Console.WriteLine("\nQuels sont les deux options ?");
            Console.WriteLine("a : SICR et SLAM ; b : SISR et SLAM ; c : SISR et SIAM ; d : SlSR et SLAM ");
            entree = Console.ReadLine();
            lettre = char.Parse(entree);

            //Réponse quatrième question
            switch (lettre)
            {
                case 'b':
                    Console.WriteLine("Bravo, c'est la bonne réponse : +2 points");
                    break;
                default:
                    Console.WriteLine("Dommage, la bonne réponse était b : -1 point");
                    break;
            }
            
            //Cinquième question
            Console.WriteLine("\nQu'est-ce que le SISR ?");
            Console.WriteLine("a : Industrie et Chimie ; b : Infrastructure et Réseau ");
            entree = Console.ReadLine();
            lettre = char.Parse(entree);

            //Réponse cinquième question
            switch (lettre)
            {
                case 'b':
                    Console.WriteLine("Bravo, c'est la bonne réponse : +2 points");
                    break;
                default:
                    Console.WriteLine("Dommage, la bonne réponse était b : -1 point");
                    break;
            }
            
            //Sixième question
            Console.WriteLine("\nQu'est-ce que le SLAM ?");
            Console.WriteLine("a : Conception et développement d'applications ; b : Maintenance et Mise en service ");
            entree = Console.ReadLine();
            lettre = char.Parse(entree);

            //Réponse cinquième question
            switch (lettre)
            {
                case 'a':
                    Console.WriteLine("Bravo, c'est la bonne réponse : +2 points");
                    break;
                default:
                    Console.WriteLine("Dommage, la bonne réponse était a : -1 point");
                    break;
            }
            
            //Septième question
            Console.WriteLine("\nLa cybersécurité est-elle comprise dans ce BTS ?");
            Console.WriteLine("a : Oui ; b : Non ");
            entree = Console.ReadLine();
            lettre = char.Parse(entree);

            //Réponse septième question
            switch (lettre)
            {
                case 'a':
                    Console.WriteLine("Bravo, c'est la bonne réponse : +2 points");
                    break;
                default:
                    Console.WriteLine("Dommage, la bonne réponse était a : -1 point");
                    break;
            }
            
            //Huitième question
            Console.WriteLine("\nApprend-t-on de la culture économique dans cette section ?");
            Console.WriteLine("a : Oui ; b : Non ");
            entree = Console.ReadLine();
            lettre = char.Parse(entree);

            //Réponse huitième question
            switch (lettre)
            {
                case 'a':
                    Console.WriteLine("Bravo, c'est la bonne réponse : +2 points");
                    break;
                default:
                    Console.WriteLine("Dommage, la bonne réponse était a : -1 point");
                    break;
            }

            //Neuvième question
            Console.WriteLine("\nApprend-t-on l'anglais aussi ?");
            Console.WriteLine("a : Bien sûr ! ; b : Bah non ; c : Malheureusement oui ");
            entree = Console.ReadLine();
            lettre = char.Parse(entree);

            //Réponse neuvième question
            switch (lettre)
            {
                case 'a':
                case 'c':
                    Console.WriteLine("Bravo, c'est la bonne réponse : +2 points");
                    break;
                default:
                    Console.WriteLine("Dommage, la bonne réponse était a (ou la c) : -1 point");
                    break;
            }

            //Dixième question
            Console.WriteLine("\nLe BTS SIO est-il un BTS ?");
            Console.WriteLine("a : Bah oui... ; b : Je ne souhaite pas répondre ; c : C'est évident ");
            entree = Console.ReadLine();
            lettre = char.Parse(entree);

            //Réponse dixième question
            switch (lettre)
            {
                case 'a':
                case 'b':
                case 'c':
                    Console.WriteLine("Bravo, c'est la bonne réponse : +2 points");
                    break;
                default:
                    Console.WriteLine("Dommage, la bonne réponse était a, b ou c : -1 point");
                    break;
            }
            //Score final obtenu par l'utilisateur
            Console.ReadKey();
        }
    }
}
