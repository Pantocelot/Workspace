﻿namespace WindowsFormTP2
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lblCH = new System.Windows.Forms.Label();
            this.lblCJ = new System.Windows.Forms.Label();
            this.cboHoraire = new System.Windows.Forms.ComboBox();
            this.cboJour = new System.Windows.Forms.ComboBox();
            this.btnAutreTicket = new System.Windows.Forms.Button();
            this.chkMajoration3D = new System.Windows.Forms.CheckBox();
            this.chkCouponReduc = new System.Windows.Forms.CheckBox();
            this.lblChoixHoraire = new System.Windows.Forms.Label();
            this.lblChoixJour = new System.Windows.Forms.Label();
            this.picTicket = new System.Windows.Forms.PictureBox();
            this.grbTarifReduit = new System.Windows.Forms.GroupBox();
            this.rdbCE = new System.Windows.Forms.RadioButton();
            this.rdbEtudiant = new System.Windows.Forms.RadioButton();
            this.rdbAutre = new System.Windows.Forms.RadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.btnCalculerTarif = new System.Windows.Forms.Button();
            this.lblTarifApplicable = new System.Windows.Forms.TextBox();
            this.lblTarifPlein = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picTicket)).BeginInit();
            this.grbTarifReduit.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(64, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "PLEIN TARIF :";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblCH
            // 
            this.lblCH.AutoSize = true;
            this.lblCH.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCH.Location = new System.Drawing.Point(65, 92);
            this.lblCH.Name = "lblCH";
            this.lblCH.Size = new System.Drawing.Size(114, 17);
            this.lblCH.TabIndex = 1;
            this.lblCH.Text = "Choisir l\'horaire :";
            this.lblCH.Click += new System.EventHandler(this.label2_Click);
            // 
            // lblCJ
            // 
            this.lblCJ.AutoSize = true;
            this.lblCJ.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCJ.Location = new System.Drawing.Point(65, 129);
            this.lblCJ.Name = "lblCJ";
            this.lblCJ.Size = new System.Drawing.Size(102, 17);
            this.lblCJ.TabIndex = 2;
            this.lblCJ.Text = "Choisir le jour :";
            // 
            // cboHoraire
            // 
            this.cboHoraire.FormattingEnabled = true;
            this.cboHoraire.Location = new System.Drawing.Point(189, 88);
            this.cboHoraire.Name = "cboHoraire";
            this.cboHoraire.Size = new System.Drawing.Size(121, 21);
            this.cboHoraire.TabIndex = 3;
            this.cboHoraire.SelectedIndexChanged += new System.EventHandler(this.cboHoraire_SelectedIndexChanged);
            // 
            // cboJour
            // 
            this.cboJour.FormattingEnabled = true;
            this.cboJour.Location = new System.Drawing.Point(189, 129);
            this.cboJour.Name = "cboJour";
            this.cboJour.Size = new System.Drawing.Size(121, 21);
            this.cboJour.TabIndex = 4;
            this.cboJour.SelectedIndexChanged += new System.EventHandler(this.cboJour_SelectedIndexChanged);
            // 
            // btnAutreTicket
            // 
            this.btnAutreTicket.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAutreTicket.Location = new System.Drawing.Point(227, 446);
            this.btnAutreTicket.Name = "btnAutreTicket";
            this.btnAutreTicket.Size = new System.Drawing.Size(159, 31);
            this.btnAutreTicket.TabIndex = 5;
            this.btnAutreTicket.Text = "AUTRE TICKET";
            this.btnAutreTicket.UseVisualStyleBackColor = true;
            // 
            // chkMajoration3D
            // 
            this.chkMajoration3D.AutoSize = true;
            this.chkMajoration3D.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkMajoration3D.Location = new System.Drawing.Point(68, 313);
            this.chkMajoration3D.Name = "chkMajoration3D";
            this.chkMajoration3D.Size = new System.Drawing.Size(192, 21);
            this.chkMajoration3D.TabIndex = 6;
            this.chkMajoration3D.Text = "Majoration Film 3D : 1,50€";
            this.chkMajoration3D.UseVisualStyleBackColor = true;
            // 
            // chkCouponReduc
            // 
            this.chkCouponReduc.AutoSize = true;
            this.chkCouponReduc.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkCouponReduc.Location = new System.Drawing.Point(68, 340);
            this.chkCouponReduc.Name = "chkCouponReduc";
            this.chkCouponReduc.Size = new System.Drawing.Size(192, 21);
            this.chkCouponReduc.TabIndex = 7;
            this.chkCouponReduc.Text = "Coupon réduction : -1,00€";
            this.chkCouponReduc.UseVisualStyleBackColor = true;
            this.chkCouponReduc.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // lblChoixHoraire
            // 
            this.lblChoixHoraire.AutoSize = true;
            this.lblChoixHoraire.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChoixHoraire.Location = new System.Drawing.Point(325, 89);
            this.lblChoixHoraire.Name = "lblChoixHoraire";
            this.lblChoixHoraire.Size = new System.Drawing.Size(125, 17);
            this.lblChoixHoraire.TabIndex = 9;
            this.lblChoixHoraire.Text = "(5,20€ à 11h00)";
            // 
            // lblChoixJour
            // 
            this.lblChoixJour.AutoSize = true;
            this.lblChoixJour.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChoixJour.Location = new System.Drawing.Point(328, 129);
            this.lblChoixJour.Name = "lblChoixJour";
            this.lblChoixJour.Size = new System.Drawing.Size(119, 17);
            this.lblChoixJour.TabIndex = 10;
            this.lblChoixJour.Text = "(5,70€ le lundi)";
            // 
            // picTicket
            // 
            this.picTicket.Location = new System.Drawing.Point(431, 166);
            this.picTicket.Name = "picTicket";
            this.picTicket.Size = new System.Drawing.Size(141, 127);
            this.picTicket.TabIndex = 11;
            this.picTicket.TabStop = false;
            // 
            // grbTarifReduit
            // 
            this.grbTarifReduit.Controls.Add(this.label6);
            this.grbTarifReduit.Controls.Add(this.rdbAutre);
            this.grbTarifReduit.Controls.Add(this.rdbEtudiant);
            this.grbTarifReduit.Controls.Add(this.rdbCE);
            this.grbTarifReduit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbTarifReduit.Location = new System.Drawing.Point(68, 166);
            this.grbTarifReduit.Name = "grbTarifReduit";
            this.grbTarifReduit.Size = new System.Drawing.Size(318, 141);
            this.grbTarifReduit.TabIndex = 12;
            this.grbTarifReduit.TabStop = false;
            this.grbTarifReduit.Text = "Tarif réduit";
            // 
            // rdbCE
            // 
            this.rdbCE.AutoSize = true;
            this.rdbCE.Location = new System.Drawing.Point(7, 31);
            this.rdbCE.Name = "rdbCE";
            this.rdbCE.Size = new System.Drawing.Size(196, 21);
            this.rdbCE.TabIndex = 0;
            this.rdbCE.TabStop = true;
            this.rdbCE.Text = "Comité d\'entreprise : 5,20€";
            this.rdbCE.UseVisualStyleBackColor = true;
            // 
            // rdbEtudiant
            // 
            this.rdbEtudiant.AutoSize = true;
            this.rdbEtudiant.Location = new System.Drawing.Point(7, 59);
            this.rdbEtudiant.Name = "rdbEtudiant";
            this.rdbEtudiant.Size = new System.Drawing.Size(193, 21);
            this.rdbEtudiant.TabIndex = 1;
            this.rdbEtudiant.TabStop = true;
            this.rdbEtudiant.Text = "Étudiant ou mineur : 5,90€";
            this.rdbEtudiant.UseVisualStyleBackColor = true;
            // 
            // rdbAutre
            // 
            this.rdbAutre.AutoSize = true;
            this.rdbAutre.Location = new System.Drawing.Point(7, 87);
            this.rdbAutre.Name = "rdbAutre";
            this.rdbAutre.Size = new System.Drawing.Size(108, 21);
            this.rdbAutre.TabIndex = 2;
            this.rdbAutre.TabStop = true;
            this.rdbAutre.Text = "Autre : 6,90€";
            this.rdbAutre.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(4, 111);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(276, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "Carte vermeil, carte famille nombreuse, demandeur emploi";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // btnCalculerTarif
            // 
            this.btnCalculerTarif.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalculerTarif.Location = new System.Drawing.Point(431, 310);
            this.btnCalculerTarif.Name = "btnCalculerTarif";
            this.btnCalculerTarif.Size = new System.Drawing.Size(141, 51);
            this.btnCalculerTarif.TabIndex = 13;
            this.btnCalculerTarif.Text = "TARIF APPLICABLE";
            this.btnCalculerTarif.UseVisualStyleBackColor = true;
            // 
            // lblTarifApplicable
            // 
            this.lblTarifApplicable.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblTarifApplicable.Location = new System.Drawing.Point(431, 367);
            this.lblTarifApplicable.Multiline = true;
            this.lblTarifApplicable.Name = "lblTarifApplicable";
            this.lblTarifApplicable.Size = new System.Drawing.Size(141, 33);
            this.lblTarifApplicable.TabIndex = 14;
            // 
            // lblTarifPlein
            // 
            this.lblTarifPlein.AutoSize = true;
            this.lblTarifPlein.Location = new System.Drawing.Point(185, 56);
            this.lblTarifPlein.Name = "lblTarifPlein";
            this.lblTarifPlein.Size = new System.Drawing.Size(35, 13);
            this.lblTarifPlein.TabIndex = 15;
            this.lblTarifPlein.Text = "label2";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 491);
            this.Controls.Add(this.lblTarifPlein);
            this.Controls.Add(this.lblTarifApplicable);
            this.Controls.Add(this.btnCalculerTarif);
            this.Controls.Add(this.grbTarifReduit);
            this.Controls.Add(this.picTicket);
            this.Controls.Add(this.lblChoixJour);
            this.Controls.Add(this.lblChoixHoraire);
            this.Controls.Add(this.chkCouponReduc);
            this.Controls.Add(this.chkMajoration3D);
            this.Controls.Add(this.btnAutreTicket);
            this.Controls.Add(this.cboJour);
            this.Controls.Add(this.cboHoraire);
            this.Controls.Add(this.lblCJ);
            this.Controls.Add(this.lblCH);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Tarifs - LE MAZARIN";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picTicket)).EndInit();
            this.grbTarifReduit.ResumeLayout(false);
            this.grbTarifReduit.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblCH;
        private System.Windows.Forms.Label lblCJ;
        private System.Windows.Forms.ComboBox cboHoraire;
        private System.Windows.Forms.ComboBox cboJour;
        private System.Windows.Forms.Button btnAutreTicket;
        private System.Windows.Forms.CheckBox chkMajoration3D;
        private System.Windows.Forms.CheckBox chkCouponReduc;
        private System.Windows.Forms.Label lblChoixHoraire;
        private System.Windows.Forms.Label lblChoixJour;
        private System.Windows.Forms.PictureBox picTicket;
        private System.Windows.Forms.GroupBox grbTarifReduit;
        private System.Windows.Forms.RadioButton rdbAutre;
        private System.Windows.Forms.RadioButton rdbEtudiant;
        private System.Windows.Forms.RadioButton rdbCE;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnCalculerTarif;
        private System.Windows.Forms.TextBox lblTarifApplicable;
        private System.Windows.Forms.Label lblTarifPlein;
    }
}

