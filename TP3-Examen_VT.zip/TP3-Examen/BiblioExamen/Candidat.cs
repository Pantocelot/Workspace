﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BiblioExamen
{
    public class Candidat
    {
        //Propriétés privées
        private string nomCandidat;
        private double noteOral;
        private double noteEcrit;

        // Les accesseurs
        public double NoteOral
        {
            get => noteOral;
        }
        public double NoteEcrit
        {
            get => noteEcrit;
        }


        //Constructeurs de la classe
        public Candidat(string sonNom, double saNoteOral, double saNoteEcrit)
        {
            nomCandidat = sonNom;
            noteOral = saNoteOral;
            noteEcrit = saNoteEcrit;
        }

        //Les méthodes
        private double moyenne()
        {
            return (2 * noteEcrit + noteOral) / 3;
        }

        public void afficher()
        {
            Console.WriteLine("Nom " + nomCandidat);
            Console.WriteLine("Moyenne " + String.Format("{0: 0.00}", moyenne()));
        }

        /// <summary>
        /// Méthode indique qui est le meilleur candidat
        /// </summary>
        /// <param name="c">un candidat</param>
        /// <returns>
        ///     false : si le candidat envoyé en paramètre a une moyenne supérieure au candidat traité
        ///     true : si la candidat traité a une moyenne supérieure au candidat envoyé en paramètre
        /// </returns>
        public bool meilleur(Candidat c)
        {
            bool resultat = false;
            if (moyenne() > c.moyenne())
                resultat = true;
            return resultat;
        }
    }
    public class Examen
    {
        //Propriétés privées
        private string noteExamen;
        private int listeCandidat;

        //Les accesseurs
        public string NomExamen
        {
            get => NomExamen;
        }

        //Constructeurs de la classe
        public Examen(int listeCandidat)
        {
            this.listeCandidat = listeCandidat;
        }

        //Les méthodes
        public effectif()
        {
            return listeCandidat;
        }
        public leader()
        {

        }
    }
}
