﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BiblioExamen;

namespace AppTest
{
    class Program
    {
        static void Main(string[] args)
        {
            //Test fonctionnement méthode meilleur de la classe candidat
            //Instanciation de 2 candidats
            Candidat cand1 = new Candidat("DUPONT", 12.5, 11);
            Candidat cand2 = new Candidat("DURANT", 15.5, 13);
            //Affichage des données pour les 2 candidats
            Console.WriteLine("AFFICHAGE DES 2 CANDIDATS");
            cand1.afficher();
            cand2.afficher();
            //Qui est le meilleur ?
            Console.WriteLine("Le meilleur candidat est ");
            if (cand1.meilleur(cand2))
                cand1.afficher();
            else
                cand2.afficher();

            Console.ReadKey();
        }
    }
}
