﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercice_1_Version_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Random rand = new Random();
            new Random();
            int returnValue = rand.Next(0, 101), entier;

            //Détermination du nombre mystère
            do
            {
                Console.WriteLine("Veuillez entrer un entier compris entre 0 et 100 : ");
                entier = int.Parse(Console.ReadLine());

                if (entier < returnValue)
                {
                    Console.WriteLine("Trop petit !");
                }
                else if (entier > returnValue)
                {
                    Console.WriteLine("Trop grand !");
                }
            }

            while (entier != returnValue);
            Console.WriteLine("Gagné !");
            Console.ReadKey();
        }
    }
}
