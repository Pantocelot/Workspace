﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TAB_Version1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Déclaration du tableau
            const int MAX = 4;
            string[] NOMS = new string[MAX];

            for(int ligne=0;ligne<MAX;ligne++)
            {
                Console.WriteLine("Entrez le nom de l'élève {0} : ", ligne + 1);
                NOMS[ligne] = Console.ReadLine();
            }

        }
    }
}
