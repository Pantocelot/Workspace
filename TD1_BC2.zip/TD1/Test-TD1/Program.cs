﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test_TD1
{
    class Program
    {
        static void Main(string[] args)
        {
            /* Test du constructeur
             * 1. Déclarer un objet employe unEmp
             * 2. Instancier cet objet avec les données suivantes :
             *    Nom : VICTOR
             *    Prénom : Paul Emile
             *    Salaire : 1600
             */




            /* Test de la méthode afficher
             * Demander l'affichage les informations de l'objet unEmp
             * */





            /* Test de la méthode calcRenum
             * Demander l'affichage du salaire calculé
             * */




            //Fin du programme
            Console.ReadKey();

        }
    }
}
