﻿namespace AppWF_TD1
{
    partial class frm_employe
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.label4 = new System.Windows.Forms.Label();
            this.CmdRemuneration = new System.Windows.Forms.Button();
            this.CmdAfficher = new System.Windows.Forms.Button();
            this.CmdCreer = new System.Windows.Forms.Button();
            this.Label3 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.TxtSalaire = new System.Windows.Forms.TextBox();
            this.TxtPrenom = new System.Windows.Forms.TextBox();
            this.TxtNom = new System.Windows.Forms.TextBox();
            this.CmdQuitter = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            this.SuspendLayout();
            // 
            // trackBar1
            // 
            this.trackBar1.Location = new System.Drawing.Point(807, 455);
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(69, 45);
            this.trackBar1.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("KacstBook", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label4.Location = new System.Drawing.Point(132, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(335, 32);
            this.label4.TabIndex = 43;
            this.label4.Text = "GESTION DES EMPLOYES";
            // 
            // CmdRemuneration
            // 
            this.CmdRemuneration.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CmdRemuneration.Location = new System.Drawing.Point(105, 274);
            this.CmdRemuneration.Name = "CmdRemuneration";
            this.CmdRemuneration.Size = new System.Drawing.Size(160, 41);
            this.CmdRemuneration.TabIndex = 41;
            this.CmdRemuneration.Text = "Remuneration";
            this.CmdRemuneration.UseVisualStyleBackColor = true;
            // 
            // CmdAfficher
            // 
            this.CmdAfficher.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CmdAfficher.Location = new System.Drawing.Point(503, 199);
            this.CmdAfficher.Name = "CmdAfficher";
            this.CmdAfficher.Size = new System.Drawing.Size(160, 37);
            this.CmdAfficher.TabIndex = 40;
            this.CmdAfficher.Text = "Afficher Employe";
            this.CmdAfficher.UseVisualStyleBackColor = true;
            // 
            // CmdCreer
            // 
            this.CmdCreer.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CmdCreer.Location = new System.Drawing.Point(503, 112);
            this.CmdCreer.Name = "CmdCreer";
            this.CmdCreer.Size = new System.Drawing.Size(160, 37);
            this.CmdCreer.TabIndex = 39;
            this.CmdCreer.Text = "Créer Employe";
            this.CmdCreer.UseVisualStyleBackColor = true;
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label3.Location = new System.Drawing.Point(42, 213);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(53, 19);
            this.Label3.TabIndex = 38;
            this.Label3.Text = "Salaire";
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.Location = new System.Drawing.Point(42, 166);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(58, 19);
            this.Label2.TabIndex = 37;
            this.Label2.Text = "Prenom";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.Location = new System.Drawing.Point(42, 122);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(39, 19);
            this.Label1.TabIndex = 36;
            this.Label1.Text = "Nom";
            // 
            // TxtSalaire
            // 
            this.TxtSalaire.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtSalaire.Location = new System.Drawing.Point(105, 213);
            this.TxtSalaire.Name = "TxtSalaire";
            this.TxtSalaire.Size = new System.Drawing.Size(139, 27);
            this.TxtSalaire.TabIndex = 35;
            // 
            // TxtPrenom
            // 
            this.TxtPrenom.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtPrenom.Location = new System.Drawing.Point(105, 166);
            this.TxtPrenom.Name = "TxtPrenom";
            this.TxtPrenom.Size = new System.Drawing.Size(288, 27);
            this.TxtPrenom.TabIndex = 34;
            // 
            // TxtNom
            // 
            this.TxtNom.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNom.Location = new System.Drawing.Point(105, 122);
            this.TxtNom.Name = "TxtNom";
            this.TxtNom.Size = new System.Drawing.Size(288, 27);
            this.TxtNom.TabIndex = 33;
            // 
            // CmdQuitter
            // 
            this.CmdQuitter.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CmdQuitter.Location = new System.Drawing.Point(503, 274);
            this.CmdQuitter.Name = "CmdQuitter";
            this.CmdQuitter.Size = new System.Drawing.Size(160, 41);
            this.CmdQuitter.TabIndex = 44;
            this.CmdQuitter.Text = "Quitter";
            this.CmdQuitter.UseVisualStyleBackColor = true;
            // 
            // frm_employe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(691, 342);
            this.Controls.Add(this.CmdQuitter);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.CmdRemuneration);
            this.Controls.Add(this.CmdAfficher);
            this.Controls.Add(this.CmdCreer);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.TxtSalaire);
            this.Controls.Add(this.TxtPrenom);
            this.Controls.Add(this.TxtNom);
            this.Controls.Add(this.trackBar1);
            this.Name = "frm_employe";
            this.Text = "Employés";
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TrackBar trackBar1;
        private System.Windows.Forms.Label label4;
        internal System.Windows.Forms.Button CmdRemuneration;
        internal System.Windows.Forms.Button CmdAfficher;
        internal System.Windows.Forms.Button CmdCreer;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.TextBox TxtSalaire;
        internal System.Windows.Forms.TextBox TxtPrenom;
        internal System.Windows.Forms.TextBox TxtNom;
        internal System.Windows.Forms.Button CmdQuitter;
    }
}

