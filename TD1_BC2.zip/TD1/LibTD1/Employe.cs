﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibTD1
{
    public class Employe
    {
        //Les attributs


        //Le constructeur


        //Méthode afficher


        //Méthode calculRenum

    }
}
