﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TD1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Déclaration des variables
            decimal montantHT, montantTTC;
            decimal tauxTVA = 0.2M;
            string strMontantHT;

            //Saisie du montant HT
            Console.Write("\nEntrez le montant HT : ");
            strMontantHT = Console.ReadLine();
            montantHT = decimal.Parse(strMontantHT);
            Console.Write("");

            //Calcul du montant TTC
            montantTTC = montantHT + montantHT * tauxTVA;
            //ou montant TTC = montant HT * (1 + tauxTVA)

            //Affichage du montant Hors-Taxe
            Console.Write("\nVous avez saisi le Montant HT suivant : ");
            Console.WriteLine(montantHT);

            //Affichage du montant Toutes Taxes Comprises
            Console.Write("Montant TTC correspondant : ");
            Console.WriteLine(montantTTC);

            //Fin du programme : attente d'une touche pour fermer la fenêtre
            Console.ReadKey();


        }
    }
}
