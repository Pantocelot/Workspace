﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercice1
{
    class Program
    {
        /*-------------------- FONCTION DE SAISIE -----------------------------
         *           VERSION NON OPTIMISEE
        |---------------------------------------------------------------------*/
        static int SAISIENB(int borneinf, int bornesup)
        {
            //déclaration variable locale
            string strsaisie;
            int saisie;
            do
            {
                do
                {
                    Console.WriteLine("VEUILLEZ SAISIR UNE VALEUR COMPRISE ENTRE {0} ET {1} : ", borneinf, bornesup);
                    strsaisie = Console.ReadLine();
                }
                while (CONTROLENOMBRE(strsaisie) == false);
                saisie = int.Parse(strsaisie);
            }
            while (saisie < borneinf || saisie > bornesup);

            //retour de la valeur saisie
            return saisie;
        }

        /*-------------------- FONCTION DE SAISIE -----------------------------
         *           ECRIRE LA VERSION OPTIMISEE
        |---------------------------------------------------------------------*/


        /*--------------------   SAISIE NOMBRE   -----------------------------
         * A MODIFIER POUR RENDRE POSSIBLE LA SAISIE DES VALEURS NEGATIVES
         |---------------------------------------------------------------------*/

        static bool CONTROLENOMBRE(string valeur)
        {
            //Déclaration variable
            bool result = true;
            //On regarde caractère par caractère s'il s'agit bien d'un chiffre
            int i = 0;
            while (i <= valeur.Length - 1 && result == true)
            {
                //Si ce n'est pas un chiffre, passer le booléen result à faux pour invalider le test de contrôle.
                if (!char.IsDigit(valeur, i))   //Equivalent à char.IsDigit(valeur, i) == false
                {
                    result = false;
                }
                i++;
            }
            return result;
        }

        //Exemple de procedure, adaptation de SAISIENB() PAS LA BONNE SOLUTION !!! ET PAS OPTIMISEE !!!
        static void PROCEDURE(int borneinf, int bornesup, out int saisie)
        {
            //déclaration variable locale
            string strsaisie;
            do
            {
                do
                {
                    Console.WriteLine("VEUILLEZ SAISIR UNE VALEUR COMPRISE ENTRE {0} ET {1} : ", borneinf, bornesup);
                    strsaisie = Console.ReadLine();
                }
                while (CONTROLENOMBRE(strsaisie) == false);
                saisie = int.Parse(strsaisie);
            }
            while (saisie < borneinf || saisie > bornesup);
            //Le retour de la valeur saisie se fait via le paramètre out saisie qui remplace l'instruction return
        }

        /**
         * Procédure Main qui s'exécute au lancement du rogramme
         * */
        static void Main(string[] args)
        {
            //Déclaration des variables
            string strlaborneinf, strlabornesup;
            int laborneinf, labornesup, saisierecup;

            //Saisie des 2 bornes
            do
            {
                Console.WriteLine("VEUILLEZ SAISIR LA BORNE INFERIEURE : ");
                strlaborneinf = Console.ReadLine();
            }
            while (CONTROLENOMBRE(strlaborneinf) == false);
            laborneinf = int.Parse(strlaborneinf);
            do
            {
                Console.WriteLine("VEUILLEZ SAISIR LA BORNE SUPERIEURE : ");
                strlabornesup = Console.ReadLine();
            }
            while ((int.TryParse(strlabornesup, out labornesup) == false) || labornesup < laborneinf);
            //Comme besoin 2 tests pour valider et que labornesup n'est pas valorisée, méthode précédente plus valide
            //while (CONTROLENOMBRE(strlabornesup) == false) || labornesup < laborneinf);
            //labornesup = int.Parse(strlabornesup);

            //APPEL DE LA FONCTION
            saisierecup = SAISIENB(laborneinf, labornesup);

            //APPEL DE LA PROCEDURE
            int saisierecup2;
            PROCEDURE(laborneinf, labornesup, out saisierecup2);

            //AFFICHAGE SAISIE
            Console.WriteLine("LA VALEUR SAISIE RENVOYEE EST {0}.", saisierecup);
            Console.WriteLine("LA VALEUR2 SAISIE RENVOYEE EST {0}.", saisierecup2);
            Console.ReadKey();
        }
    }
}
