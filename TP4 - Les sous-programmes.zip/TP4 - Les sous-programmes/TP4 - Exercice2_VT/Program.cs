﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP4_Exercice2_VT
{
    class Program
    {
        // Sous Programme Test Nombre entier
        static bool ControleNb(string valeur)
        {
            //Déclaration variable
            bool result = true;
            //On regarde caractère par caractère s'il s'agit bien d'un chiffre
            int i = 0;
            while (i <= valeur.Length - 1 && result == true)
            {
                //Si ce n'est pas un chiffre, passer le booléen result à faux pour invalider le test de contrôle.
                if (!char.IsDigit(valeur, i))
                {
                    result = false;
                }
                i++;
            }
            return result;
        }

        //Decimal en Binaire
        static int DecToBin(int valeur)
        {
            String Binaire = "";
            int i = 7;
            double rest;

            while (i >= 0 && valeur > 0)
            {
                rest = Math.Pow(2, i);
                if (valeur >= rest)
                {
                    Binaire = Binaire + "1";
                    valeur = valeur - Convert.ToInt32(rest);
                }
                else
                {
                    Binaire = Binaire + "0";
                }
                i--;
            }
            valeur = int.Parse(Binaire);
            return valeur;
        }
        static void Main(string[] args)
        {
            //variables
            int DoctetA, DoctetB, DoctetC, DoctetD; //octet decimal
            int BoctetA, BoctetB, BoctetC, BoctetD; //octet binaire
            string StrDoctetA, StrDoctetB, StrDoctetC, StrDoctetD; //octet string

            /*--------------------------------------------------DEMANDE LES DIFFERENTS OCTETS-------------------------------------------------------------------*/

            do
            {
                Console.Write("\nEntre le premier octet de ton addresse IP : ");
                StrDoctetA = Console.ReadLine();
            }
            while (ControleNb(StrDoctetA) == false);
            DoctetA = int.Parse(StrDoctetA);
            BoctetA = DecToBin(DoctetA);



            do
            {
                Console.Write("\nEntre le deuxieme octet de ton addresse IP : ");
                StrDoctetB = Console.ReadLine();
            }
            while (ControleNb(StrDoctetB) == false);
            DoctetB = int.Parse(StrDoctetB);
            BoctetB = DecToBin(DoctetB);

            do
            {
                Console.Write("\nEntre le troisieme octet de ton addresse IP : ");
                StrDoctetC = Console.ReadLine();
            }
            while (ControleNb(StrDoctetC) == false);
            DoctetC = int.Parse(StrDoctetC);
            BoctetC = DecToBin(DoctetC);

            do
            {
                Console.Write("\nEntre le quatrieme octet de ton addresse IP : ");
                StrDoctetD = Console.ReadLine();
            }
            while (ControleNb(StrDoctetD) == false);
            DoctetD = int.Parse(StrDoctetD);
            BoctetD = DecToBin(DoctetD);

            Console.Clear();
            Console.WriteLine("Ton adresse decimal : {0}.{1}.{2}.{3}", DoctetA, DoctetB, DoctetC, DoctetD);
            Console.WriteLine("Ton adresse binaire : {0}.{1}.{2}.{3}", BoctetA, BoctetB, BoctetC, BoctetD);
            Console.ReadKey();
        }
    }
}
