﻿namespace WindowsFormTP1
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.valideBtn = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.inputLbl = new System.Windows.Forms.Label();
            this.inputLbl2 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // valideBtn
            // 
            this.valideBtn.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.valideBtn.Location = new System.Drawing.Point(100, 161);
            this.valideBtn.Name = "valideBtn";
            this.valideBtn.Size = new System.Drawing.Size(120, 23);
            this.valideBtn.TabIndex = 0;
            this.valideBtn.Text = "Connexion";
            this.valideBtn.UseVisualStyleBackColor = true;
            this.valideBtn.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(100, 58);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(120, 20);
            this.textBox1.TabIndex = 1;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // inputLbl
            // 
            this.inputLbl.AutoSize = true;
            this.inputLbl.Location = new System.Drawing.Point(23, 61);
            this.inputLbl.Name = "inputLbl";
            this.inputLbl.Size = new System.Drawing.Size(53, 13);
            this.inputLbl.TabIndex = 3;
            this.inputLbl.Text = "Identifiant";
            this.inputLbl.Click += new System.EventHandler(this.label1_Click);
            // 
            // inputLbl2
            // 
            this.inputLbl2.AutoSize = true;
            this.inputLbl2.Location = new System.Drawing.Point(23, 114);
            this.inputLbl2.Name = "inputLbl2";
            this.inputLbl2.Size = new System.Drawing.Size(71, 13);
            this.inputLbl2.TabIndex = 4;
            this.inputLbl2.Text = "Mot de passe";
            this.inputLbl2.Click += new System.EventHandler(this.label2_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(100, 111);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(120, 20);
            this.textBox2.TabIndex = 5;
            this.textBox2.UseSystemPasswordChar = true;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 247);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.inputLbl2);
            this.Controls.Add(this.inputLbl);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.valideBtn);
            this.Name = "Form1";
            this.Text = "Identifiez-vous...";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button valideBtn;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label inputLbl;
        private System.Windows.Forms.Label inputLbl2;
        private System.Windows.Forms.TextBox textBox2;
    }
}

