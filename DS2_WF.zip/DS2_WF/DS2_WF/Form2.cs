﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DS2_WF
{
    public partial class AccueilForm : Form
    {
        public AccueilForm()
        {
            InitializeComponent();
            //Déclaration et initalisation variables locales
            string name = "vide";
            string fonction = "vide";
            //Tant que login ou pwd pas correct
            while (name != "Paul" || fonction != "Administrateur")
            {
                //Instanciation formulaire loginForm
                LoginForm LF = new LoginForm();
                //Si le bouton sur le formulaire loginForm appuyé est Yes
                if (LF.ShowDialog() == DialogResult.Yes)
                {
                    //Affectation des valeurs des zones de texte Login et Pwd dans variables locales
                    name = LF.Login;
                    fonction = LF.Pwd;
                    //Affichage si nécessaire du message d'erreur
                    if (!(name.Equals("Paul")) || !(fonction.Equals("Administrateur")))
                    {
                        MessageBox.Show("Erreur, vous devez préciser un prénom et une fonction!", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }
            }
            //Modification du texte du label sur la page
            loginLbl.Text = "Bienvenue " + name + "! Vous êtes connecté comme " + fonction + "!";
            {
                AccueilForm LoginForm = new AccueilForm();
            }
        }
    }
}
