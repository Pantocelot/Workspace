﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DS2_WF
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }
        //Déclaration des variables
        public string Login
        {
            get { return loginTB.Text;  }
        }
        public string Pwd
        {
            get { return fonctioncbo.Text; }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AccueilForm LoginForm = new AccueilForm();
        }
    }
}
