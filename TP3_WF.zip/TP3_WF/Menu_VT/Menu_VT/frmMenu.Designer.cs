﻿namespace Menu_VT
{
    partial class frmMenu
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.GestionMenu = new System.Windows.Forms.MenuStrip();
            this.mnuFichier = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuQuitter = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuQCM = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuEcran = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuCouleur = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuBlanc = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuBleu = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuRouge = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuGris = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuTaille = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuPetit = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuGrand = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuHorloge = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuDate = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuHeure = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAide = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuRDJ = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuPRM = new System.Windows.Forms.ToolStripMenuItem();
            this.saisieSansAideToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.affichageEnListeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAPD = new System.Windows.Forms.ToolStripMenuItem();
            this.lblDateHeure = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.QuestionCinq = new System.Windows.Forms.Label();
            this.QuestionQuatre = new System.Windows.Forms.Label();
            this.QuestionTrois = new System.Windows.Forms.Label();
            this.QuestionDeux = new System.Windows.Forms.Label();
            this.QuestionUne = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnLG = new System.Windows.Forms.Button();
            this.btnBYE = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.GestionMenu.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // GestionMenu
            // 
            this.GestionMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuFichier,
            this.mnuEcran,
            this.mnuHorloge,
            this.mnuAide});
            this.GestionMenu.Location = new System.Drawing.Point(0, 0);
            this.GestionMenu.Name = "GestionMenu";
            this.GestionMenu.Size = new System.Drawing.Size(800, 24);
            this.GestionMenu.TabIndex = 0;
            this.GestionMenu.Text = "menuStrip1";
            // 
            // mnuFichier
            // 
            this.mnuFichier.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuQuitter,
            this.mnuQCM});
            this.mnuFichier.Name = "mnuFichier";
            this.mnuFichier.Size = new System.Drawing.Size(54, 20);
            this.mnuFichier.Text = "&Fichier";
            // 
            // mnuQuitter
            // 
            this.mnuQuitter.Name = "mnuQuitter";
            this.mnuQuitter.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Q)));
            this.mnuQuitter.Size = new System.Drawing.Size(154, 22);
            this.mnuQuitter.Text = "&Quitter";
            this.mnuQuitter.Click += new System.EventHandler(this.mnuQuitter_Click);
            // 
            // mnuQCM
            // 
            this.mnuQCM.Name = "mnuQCM";
            this.mnuQCM.Size = new System.Drawing.Size(154, 22);
            this.mnuQCM.Text = "&Démarrer QCM";
            // 
            // mnuEcran
            // 
            this.mnuEcran.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuCouleur,
            this.mnuTaille});
            this.mnuEcran.Name = "mnuEcran";
            this.mnuEcran.Size = new System.Drawing.Size(48, 20);
            this.mnuEcran.Text = "&Ecran";
            // 
            // mnuCouleur
            // 
            this.mnuCouleur.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuBlanc,
            this.mnuBleu,
            this.mnuRouge,
            this.mnuGris});
            this.mnuCouleur.Name = "mnuCouleur";
            this.mnuCouleur.Size = new System.Drawing.Size(116, 22);
            this.mnuCouleur.Text = "&Couleur";
            // 
            // mnuBlanc
            // 
            this.mnuBlanc.Name = "mnuBlanc";
            this.mnuBlanc.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.B)));
            this.mnuBlanc.Size = new System.Drawing.Size(149, 22);
            this.mnuBlanc.Text = "&Blanc";
            this.mnuBlanc.Click += new System.EventHandler(this.mnuBlanc_Click);
            // 
            // mnuBleu
            // 
            this.mnuBleu.Name = "mnuBleu";
            this.mnuBleu.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.L)));
            this.mnuBleu.Size = new System.Drawing.Size(149, 22);
            this.mnuBleu.Text = "&Bleu";
            this.mnuBleu.Click += new System.EventHandler(this.mnuBleu_Click);
            // 
            // mnuRouge
            // 
            this.mnuRouge.Name = "mnuRouge";
            this.mnuRouge.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.R)));
            this.mnuRouge.Size = new System.Drawing.Size(149, 22);
            this.mnuRouge.Text = "&Rouge";
            this.mnuRouge.Click += new System.EventHandler(this.mnuRouge_Click);
            // 
            // mnuGris
            // 
            this.mnuGris.Name = "mnuGris";
            this.mnuGris.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.I)));
            this.mnuGris.Size = new System.Drawing.Size(149, 22);
            this.mnuGris.Text = "Gris";
            this.mnuGris.Click += new System.EventHandler(this.mnuGris_Click);
            // 
            // mnuTaille
            // 
            this.mnuTaille.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuPetit,
            this.mnuGrand});
            this.mnuTaille.Name = "mnuTaille";
            this.mnuTaille.Size = new System.Drawing.Size(116, 22);
            this.mnuTaille.Text = "&Taille";
            // 
            // mnuPetit
            // 
            this.mnuPetit.Name = "mnuPetit";
            this.mnuPetit.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.P)));
            this.mnuPetit.Size = new System.Drawing.Size(148, 22);
            this.mnuPetit.Text = "&Petit";
            this.mnuPetit.Click += new System.EventHandler(this.mnuPetit_Click);
            // 
            // mnuGrand
            // 
            this.mnuGrand.Name = "mnuGrand";
            this.mnuGrand.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.G)));
            this.mnuGrand.Size = new System.Drawing.Size(148, 22);
            this.mnuGrand.Text = "Grand";
            this.mnuGrand.Click += new System.EventHandler(this.mnuGrand_Click);
            // 
            // mnuHorloge
            // 
            this.mnuHorloge.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuDate,
            this.mnuHeure});
            this.mnuHorloge.Name = "mnuHorloge";
            this.mnuHorloge.Size = new System.Drawing.Size(62, 20);
            this.mnuHorloge.Text = "&Horloge";
            // 
            // mnuDate
            // 
            this.mnuDate.Name = "mnuDate";
            this.mnuDate.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D)));
            this.mnuDate.Size = new System.Drawing.Size(149, 22);
            this.mnuDate.Text = "&Date";
            this.mnuDate.Click += new System.EventHandler(this.mnuDate_Click);
            // 
            // mnuHeure
            // 
            this.mnuHeure.Name = "mnuHeure";
            this.mnuHeure.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.H)));
            this.mnuHeure.Size = new System.Drawing.Size(149, 22);
            this.mnuHeure.Text = "&Heure";
            this.mnuHeure.Click += new System.EventHandler(this.mnuHeure_Click);
            // 
            // mnuAide
            // 
            this.mnuAide.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuRDJ,
            this.mnuPRM,
            this.mnuAPD});
            this.mnuAide.Name = "mnuAide";
            this.mnuAide.Size = new System.Drawing.Size(43, 20);
            this.mnuAide.Text = "&Aide";
            // 
            // mnuRDJ
            // 
            this.mnuRDJ.Name = "mnuRDJ";
            this.mnuRDJ.Size = new System.Drawing.Size(180, 22);
            this.mnuRDJ.Text = "&Règles du jeu";
            this.mnuRDJ.Click += new System.EventHandler(this.mnuRDJ_Click);
            // 
            // mnuPRM
            // 
            this.mnuPRM.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saisieSansAideToolStripMenuItem,
            this.affichageEnListeToolStripMenuItem});
            this.mnuPRM.Name = "mnuPRM";
            this.mnuPRM.Size = new System.Drawing.Size(180, 22);
            this.mnuPRM.Text = "&Paramètres";
            // 
            // saisieSansAideToolStripMenuItem
            // 
            this.saisieSansAideToolStripMenuItem.Name = "saisieSansAideToolStripMenuItem";
            this.saisieSansAideToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.saisieSansAideToolStripMenuItem.Text = "&Saisie sans aide";
            // 
            // affichageEnListeToolStripMenuItem
            // 
            this.affichageEnListeToolStripMenuItem.Name = "affichageEnListeToolStripMenuItem";
            this.affichageEnListeToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.affichageEnListeToolStripMenuItem.Text = "Affichage en liste";
            // 
            // mnuAPD
            // 
            this.mnuAPD.Name = "mnuAPD";
            this.mnuAPD.Size = new System.Drawing.Size(180, 22);
            this.mnuAPD.Text = "&À propos de...";
            this.mnuAPD.Click += new System.EventHandler(this.mnuAPD_Click);
            // 
            // lblDateHeure
            // 
            this.lblDateHeure.AutoSize = true;
            this.lblDateHeure.Location = new System.Drawing.Point(43, 78);
            this.lblDateHeure.Name = "lblDateHeure";
            this.lblDateHeure.Size = new System.Drawing.Size(0, 13);
            this.lblDateHeure.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.QuestionCinq);
            this.groupBox1.Controls.Add(this.QuestionQuatre);
            this.groupBox1.Controls.Add(this.QuestionTrois);
            this.groupBox1.Controls.Add(this.QuestionDeux);
            this.groupBox1.Controls.Add(this.QuestionUne);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(25, 121);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(440, 256);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Les Questions";
            // 
            // QuestionCinq
            // 
            this.QuestionCinq.AutoSize = true;
            this.QuestionCinq.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.QuestionCinq.Location = new System.Drawing.Point(21, 192);
            this.QuestionCinq.Name = "QuestionCinq";
            this.QuestionCinq.Size = new System.Drawing.Size(277, 20);
            this.QuestionCinq.TabIndex = 4;
            this.QuestionCinq.Text = "Y-a-t-il moins sûr que l\'incertain ?";
            this.QuestionCinq.Visible = false;
            // 
            // QuestionQuatre
            // 
            this.QuestionQuatre.AutoSize = true;
            this.QuestionQuatre.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.QuestionQuatre.Location = new System.Drawing.Point(21, 157);
            this.QuestionQuatre.Name = "QuestionQuatre";
            this.QuestionQuatre.Size = new System.Drawing.Size(393, 20);
            this.QuestionQuatre.TabIndex = 3;
            this.QuestionQuatre.Text = "Qui est le plus fou, du fou ou du fou qui le suit ?";
            this.QuestionQuatre.Visible = false;
            // 
            // QuestionTrois
            // 
            this.QuestionTrois.AutoSize = true;
            this.QuestionTrois.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.QuestionTrois.Location = new System.Drawing.Point(21, 120);
            this.QuestionTrois.Name = "QuestionTrois";
            this.QuestionTrois.Size = new System.Drawing.Size(353, 20);
            this.QuestionTrois.TabIndex = 2;
            this.QuestionTrois.Text = "Quelle est la différence entre vous et moi ?";
            this.QuestionTrois.Visible = false;
            // 
            // QuestionDeux
            // 
            this.QuestionDeux.AutoSize = true;
            this.QuestionDeux.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.QuestionDeux.Location = new System.Drawing.Point(21, 80);
            this.QuestionDeux.Name = "QuestionDeux";
            this.QuestionDeux.Size = new System.Drawing.Size(295, 20);
            this.QuestionDeux.TabIndex = 1;
            this.QuestionDeux.Text = "Quel âge avait Rimbaud à sa mort ?";
            this.QuestionDeux.Visible = false;
            // 
            // QuestionUne
            // 
            this.QuestionUne.AutoSize = true;
            this.QuestionUne.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.QuestionUne.Location = new System.Drawing.Point(21, 38);
            this.QuestionUne.Name = "QuestionUne";
            this.QuestionUne.Size = new System.Drawing.Size(400, 20);
            this.QuestionUne.TabIndex = 0;
            this.QuestionUne.Text = "Combien peut-on casser de pattes à un canard ?";
            this.QuestionUne.Visible = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(520, 121);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(268, 256);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Vos Réponses";
            // 
            // btnLG
            // 
            this.btnLG.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLG.Location = new System.Drawing.Point(178, 384);
            this.btnLG.Name = "btnLG";
            this.btnLG.Size = new System.Drawing.Size(114, 43);
            this.btnLG.TabIndex = 4;
            this.btnLG.Text = "Let\'s Go";
            this.btnLG.UseVisualStyleBackColor = true;
            // 
            // btnBYE
            // 
            this.btnBYE.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBYE.Location = new System.Drawing.Point(611, 384);
            this.btnBYE.Name = "btnBYE";
            this.btnBYE.Size = new System.Drawing.Size(114, 43);
            this.btnBYE.TabIndex = 5;
            this.btnBYE.Text = "Bye";
            this.btnBYE.UseVisualStyleBackColor = true;
            this.btnBYE.Click += new System.EventHandler(this.btnBYE_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(118, 78);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(311, 26);
            this.label1.TabIndex = 6;
            this.label1.Text = "Bienvenue au QCM des SIO";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(520, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(112, 20);
            this.label2.TabIndex = 7;
            this.label2.Text = "Votre score :";
            // 
            // textBox1
            // 
            this.textBox1.Enabled = false;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(638, 57);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(67, 20);
            this.textBox1.TabIndex = 8;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // frmMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnBYE);
            this.Controls.Add(this.btnLG);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lblDateHeure);
            this.Controls.Add(this.GestionMenu);
            this.MainMenuStrip = this.GestionMenu;
            this.Name = "frmMenu";
            this.Text = "QCM des SIO1";
            this.Load += new System.EventHandler(this.frmMenu_Load);
            this.GestionMenu.ResumeLayout(false);
            this.GestionMenu.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip GestionMenu;
        private System.Windows.Forms.ToolStripMenuItem mnuFichier;
        private System.Windows.Forms.ToolStripMenuItem mnuQuitter;
        private System.Windows.Forms.ToolStripMenuItem mnuEcran;
        private System.Windows.Forms.ToolStripMenuItem mnuCouleur;
        private System.Windows.Forms.ToolStripMenuItem mnuBlanc;
        private System.Windows.Forms.ToolStripMenuItem mnuBleu;
        private System.Windows.Forms.ToolStripMenuItem mnuRouge;
        private System.Windows.Forms.ToolStripMenuItem mnuGris;
        private System.Windows.Forms.ToolStripMenuItem mnuTaille;
        private System.Windows.Forms.ToolStripMenuItem mnuPetit;
        private System.Windows.Forms.ToolStripMenuItem mnuGrand;
        private System.Windows.Forms.ToolStripMenuItem mnuHorloge;
        private System.Windows.Forms.ToolStripMenuItem mnuDate;
        private System.Windows.Forms.ToolStripMenuItem mnuHeure;
        private System.Windows.Forms.Label lblDateHeure;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnLG;
        private System.Windows.Forms.Button btnBYE;
        private System.Windows.Forms.ToolStripMenuItem mnuQCM;
        private System.Windows.Forms.ToolStripMenuItem mnuAide;
        private System.Windows.Forms.ToolStripMenuItem mnuRDJ;
        private System.Windows.Forms.ToolStripMenuItem mnuPRM;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ToolStripMenuItem saisieSansAideToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem affichageEnListeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mnuAPD;
        private System.Windows.Forms.Label QuestionCinq;
        private System.Windows.Forms.Label QuestionQuatre;
        private System.Windows.Forms.Label QuestionTrois;
        private System.Windows.Forms.Label QuestionDeux;
        private System.Windows.Forms.Label QuestionUne;
    }
}

