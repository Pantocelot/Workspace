﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Menu_VT
{
    public partial class frmMenu : Form
    {
        public frmMenu()
        {
            InitializeComponent();
        }

        private void frmMenu_Load(object sender, EventArgs e)
        {
            //Désactivation du menu gris
            mnuGris.Enabled = false;
            //Désactivation du menu petit
            mnuPetit.Enabled = false;
            //Définition de la couleur d'arrière plan de l'étiquette
            lblDateHeure.BackColor = System.Drawing.Color.Gainsboro;
        }

        private void mnuQuitter_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Êtes-vous sûr(e)de vouloir quitter ?", "Demande de confirmation",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                Application.Exit();
        }

        private void mnuBlanc_Click(object sender, EventArgs e)
        {
            //Définition de la couleur de fond de la feuille à blanc
            this.BackColor = System.Drawing.Color.White;
            //Désactivation du menu blanc
            mnuBlanc.Enabled = false;
            //Activation des menus bleu, rouge et gris
            mnuBleu.Enabled = true;
            mnuRouge.Enabled = true;
            mnuGris.Enabled = true;
        }

        private void mnuBleu_Click(object sender, EventArgs e)
        {
            //Définition de la couleur de fond de la feuille à bleu
            this.BackColor = System.Drawing.Color.Blue;
            //Désactivation du menu bleu
            mnuBleu.Enabled = false;
            //Activation des menus blanc, rouge et gris
            mnuBlanc.Enabled = true;
            mnuRouge.Enabled = true;
            mnuGris.Enabled = true;
        }

        private void mnuRouge_Click(object sender, EventArgs e)
        {
            //Définition de la couleur de fond de la feuille à rouge
            this.BackColor = System.Drawing.Color.Red;
            //Désactivation du menu rouge
            mnuRouge.Enabled = false;
            //Activation des menus blanc, bleu et gris
            mnuBlanc.Enabled = true;
            mnuBleu.Enabled = true;
            mnuGris.Enabled = true;
        }

        private void mnuGris_Click(object sender, EventArgs e)
        {
            //Définition de la couleur de fond de la feuille à gris
            this.BackColor = System.Drawing.Color.Gray;
            //Désactivation du menu gris
            mnuGris.Enabled = false;
            //Activation des menus blanc, rouge et bleu
            mnuBlanc.Enabled = true;
            mnuRouge.Enabled = true;
            mnuBleu.Enabled = true;
        }

        private void mnuPetit_Click(object sender, EventArgs e)
        {
            //Réduction de la fenêtre
            this.WindowState = System.Windows.Forms.FormWindowState.Normal;
            mnuPetit.Enabled = false;
            mnuGrand.Enabled = true;
        }

        private void mnuGrand_Click(object sender, EventArgs e)
        {
            //Agrandissement de la fenêtre
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            mnuPetit.Enabled = true;
            mnuGrand.Enabled = false;
        }

        private void mnuDate_Click(object sender, EventArgs e)
        {
            //Affichage de la date système dans l'étiquette en la convertissant en type string
            lblDateHeure.Text = System.DateTime.Now.ToShortDateString();
        }

        private void mnuHeure_Click(object sender, EventArgs e)
        {
            //Affichage de l'heure système dans l'étiqueete en la convertissant en type string
            lblDateHeure.Text = System.DateTime.Now.ToShortTimeString();
        }

        private void btnBYE_Click(object sender, EventArgs e)
        {
            //Affichage de la fenêtre de confirmation
            if (MessageBox.Show("Êtes-vous sûr(e) de vouloir quitter ?", "Demande de confirmation",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                Application.Exit();
        }

        private void mnuAPD_Click(object sender, EventArgs e)
        {
            //Affichage des détails du logiciel
            MessageBox.Show("Auteur : Vincent Timbert\n Version du logiciel : 1.0");
        }

        private void mnuRDJ_Click(object sender, EventArgs e)
        {
            //Affichage des règles du jeu
            MessageBox.Show("Bienvenue au QCM des SIO !\nCliquez sur Let's Go pour lancer le QCM" +
                "\nCliquez sur Bye pour quitter la fenêtre\nAllez sur Aide > Paramètres pour changer de mode de réponse" +
                "\nBonne chance !");
        }
    }
}
