﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B12D_DM2_VT
{
    class Program
        {
            static bool NbTest(string value)
            {
                bool result = true;
                int i = 0;

                while (i <= value.Length - 1 && result == true)
                {
                    if (!char.IsDigit(value, i))
                    {
                        result = false;
                    }
                    i++;
                }
                return result;
            }


            static int TestStarP(int valeur)
            {
                
                        //Déclaration des variables
            
                int Étoiles = 0;

                if (valeur == 2)
                {
                    Étoiles = 12;
                }
                if (valeur == 3)
                {
                    Étoiles = 15;
                }
                if (valeur == 4)
                {
                    Étoiles = 18;
                }

                return Étoiles;
            }

            static void Main(string[] args)
            {
                int Ciel = 0, Étoiles = 0, Mage = 0, Dé, Joueurs = 0;
                string StrP;
                int[] Joueur = new int[4];

                Random rnd = new Random();

                bool TestNbP = false;

                        //Déclaration des participants

                do
                {
                    Console.Write("Nombre de participants (de 2 à 4 joueurs) : ");
                    StrP = Console.ReadLine();
                    if (NbTest(StrP) == true && int.Parse(StrP) > 1 && int.Parse(StrP) < 5)
                    {
                        Joueurs = int.Parse(StrP);
                        TestNbP = true;
                    }
                    else
                    {
                        TestNbP = false;
                    }
                } while (TestNbP == false);

                Étoiles = TestStarP(Joueurs);

                do
                {
                    int TourJoueur = 0;

                    for (int i = 0; i < Joueurs; i++)
                    {

                        //Lancement du dé

                        TourJoueur = TourJoueur + 1;

                        Console.WriteLine("~ C'est au tour du joueur {0} ~", TourJoueur);
                        Console.WriteLine("~ Le joueur {0} est actuellement sur la case {1} ~", TourJoueur, Joueur[i]);
                        Console.WriteLine("Appuyez sur une touche pour lancer le dé");
                        Console.ReadKey();
                        Dé = rnd.Next(1, 6);
                        Joueur[i] = Joueur[i] + Dé;
                        Console.WriteLine("Vous avez fait {0} avec le dé\n", Dé);
                        Console.WriteLine("~ Le joueur {0} est maintenant sur la case {1} ~", TourJoueur, Joueur[i]);
                        Console.ReadKey();

                        if (Joueur[i] > 19)
                        {
                            Joueur[i] = Joueur[i] - 19;
                        }
                        
                        //Création de la simple case 

                        if (Joueur[i] == 3 || Joueur[i] == 5 || Joueur[i] == 8 || Joueur[i] == 10 || Joueur[i] == 13 || Joueur[i] == 14 || Joueur[i] == 16)
                        {
                            Console.WriteLine("C'est une case simple, rien ne se passe");
                            Console.ReadKey();
                        }

                        //Création de la Case Chapeau Mage

                        if (Joueur[i] == 4 || Joueur[i] == 11 || Joueur[i] == 17)
                        {
                            Console.WriteLine("C'est une case Chapeau Mage");
                            Console.WriteLine("Une nouvelle pièce du puzzle mage a été placée");
                            Mage = Mage + 1;
                            Console.ReadKey();
                            Console.Write("Vous avez {0} étoiles et {1} pièces du puzzle mage \nAppuyez sur une touche pour continuer", Ciel, Mage);
                            Console.ReadKey();
                        }
                        
                        //Création de la Case Chauve Souris

                        if (Joueur[i] == 12 || Joueur[i] == 19)
                        {
                            Console.WriteLine("C'est une case Chauve Souris");
                            Console.WriteLine("Une étoile vient d'être enlevée");
                            Ciel = Ciel - 1;
                            Console.ReadKey();
                            Console.Write("Vous avez {0} étoiles et {1} pièces du puzzle mage \nAppuyez sur une touche pour continuer", Ciel, Mage);
                            Console.ReadKey();
                        }
                            Console.Clear();

                        //Création de la Case Étoiles

                        if (Joueur[i] == 1 || Joueur[i] == 6 || Joueur[i] == 15)
                        {
                            Console.WriteLine("C'est une case Étoiles");
                            Console.WriteLine("Une étoile a été placée dans le ciel");
                            Ciel = Ciel + 1;
                            Console.ReadKey();

                            Console.Write("Vous avez {0} étoiles et {1} pièces du puzzle mage \nAppuyez sur une touche pour continuer", Ciel, Mage);
                            Console.ReadKey();
                        }
                        if (Joueur[i] == 9)
                        {
                            Console.WriteLine("C'est une case Étoiles");
                            Console.WriteLine("Trois étoiles ont été placées dans le ciel");
                            Ciel = Ciel + 3;
                            Console.ReadKey();

                            Console.Write("Vous avez {0} étoiles et {1} pièces du puzzle mage \nAppuyez sur une touche pour continuer", Ciel, Mage);
                            Console.ReadKey();
                        }
                        if (Joueur[i] == 18)
                        {
                            Console.WriteLine("C'est une case Étoiles");
                            Console.WriteLine("Deux étoiles ont été placées dans le ciel");
                            Ciel = Ciel + 2;
                            Console.ReadKey();

                            Console.Write("Vous avez {0} étoiles et {1} pièces du puzzle mage \nAppuyez sur une touche pour continuer", Ciel, Mage);
                            Console.ReadKey();
                        }

                        //Création de la Case Chouette

                        if (Joueur[i] == 2)
                        {
                            Console.WriteLine("C'est une case Chouette");
                            TestNbP = false;
                            do
                            {
                                Console.WriteLine("\nSouhaitez-vous enlever une pièce du puzzle mage ou placer deux étoiles dans le ciel ?");
                                Console.Write("Tapez '1' pour la pièce du puzzle mage ou '2' pour le placement de deux étoiles : ");
                                StrP = Console.ReadLine();

                                if (NbTest(StrP) == true && int.Parse(StrP) < 3 && int.Parse(StrP) > 0)
                                {
                                    if (Mage == 0)
                                    {
                                        Console.WriteLine("Le puzzle du mage ne possède aucune pièce donc deux étoiles ont été placées dans le ciel");
                                        Ciel = Ciel + 2;
                                        Console.ReadKey();
                                    }
                                    else
                                    {
                                        if (int.Parse(StrP) == 1)
                                        {
                                            Console.WriteLine("Une pièce du puzzle mage vient d'être enlevée");
                                            Mage = Mage - 1;
                                        }
                                        else
                                        {
                                            Console.WriteLine("Deux étoiles ont été placées dans le ciel");
                                            Ciel = Ciel + 2;
                                        }
                                    }
                                    TestNbP = true;
                                }
                            } while (TestNbP == false);

                            Console.Write("Vous avez {0} étoiles et {1} pièces du puzzle mage \nAppuyez sur une touche pour continuer", Ciel, Mage);
                            Console.ReadKey();
                        }

                        //Création de la Case Grimoire

                        if (Joueur[i] == 7)
                        {
                            Console.WriteLine("C'est une case Grimoire, relancez le dé");
                            Console.WriteLine("Si le dé fait 1, 2 ou 3, deux étoiles seront enlevées du ciel");
                            Console.WriteLine("Si le dé fait 4, 5 ou 6, deux étoiles seront placées dans le ciel");
                            Console.Write("Appuyez sur une touche pour lancer le dé");
                            Console.ReadKey();
                            Dé = rnd.Next(1, 6);

                            Console.Write("\nVous avez fait " + Dé);
                            Console.ReadKey();
                            if (Dé == 1 || Dé == 2 || Dé == 3)
                            {
                                if (Ciel < 2)
                                {
                                    Ciel = 0;
                                }
                                else
                                {
                                    Ciel = Ciel - 2;
                                }
                            }
                            else
                            {
                                Ciel = Ciel + 2;
                            }

                            Console.Write("Vous avez {0} étoiles et {1} pièces du puzzle mage \nAppuyez sur une touche pour continuer", Ciel, Mage);
                            Console.ReadKey();
                        }
                    }

                } while (Ciel != Étoiles || Mage < 6);

                        //Fin du programme
            
                            Console.Clear();
                            Console.WriteLine("... " + Joueurs + " ...");
                            Console.WriteLine("... " + Étoiles + " ...");
                            Console.ReadKey();
            }
        }
    }
