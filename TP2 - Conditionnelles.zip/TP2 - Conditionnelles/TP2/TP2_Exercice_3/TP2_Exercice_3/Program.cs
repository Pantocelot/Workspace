﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP2_Exercice_3
{
    class Program
    {
        static void Main(string[] args)
        {
            //Déclaration des variables
            decimal salaire, impot = 0;
            string strsalaire;

            //Assignation de la variable "salaire"
            Console.WriteLine("Veuillez entrer votre salaire : ");
            strsalaire = Console.ReadLine();
            salaire = int.Parse(strsalaire);

            //Déclaration des impôts
            if (salaire<=3100)
            {
                impot = 230;
            }

            if (salaire>3100 && salaire<7700)
            {
                impot = 230 + (salaire - 3100 * 0.01M);
            }

            if (salaire>=7700)
            {
                impot = 400 + (salaire - 7700 * 0.015M);
            }

            if (impot>500)
            {
                impot = 500;
            }

            Console.WriteLine("Impôt annuel : " + impot);
            Console.ReadKey();
        }
    }
}
