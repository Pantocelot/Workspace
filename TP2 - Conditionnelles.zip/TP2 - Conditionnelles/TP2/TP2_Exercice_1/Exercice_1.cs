﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Déclaration des variables
            decimal N1, N2, N3;
            string strN1, strN2, strN3;

            //Saisie des trois nombres
            Console.Write("\nEntrez un premier nombre : ");
            strN1 = Console.ReadLine();
            N1 = decimal.Parse(strN1);
            Console.Write("\nEntrez un second nombre : ");
            strN2 = Console.ReadLine();
            N2 = decimal.Parse(strN2);
            Console.Write("\nEntrez un troisième nombre : ");
            strN3 = Console.ReadLine();
            N3 = decimal.Parse(strN3);

            Console.ReadKey();


        }
    }
}
