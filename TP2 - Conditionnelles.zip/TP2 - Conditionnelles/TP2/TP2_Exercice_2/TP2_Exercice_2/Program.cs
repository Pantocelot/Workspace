﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP2_Exercice_2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Déclaration de la variable
            string entree;
            char lettre;

            //Entrée de la variable
            Console.WriteLine("Entrez une lettre : ");
            entree = Console.ReadLine();
            lettre=char.Parse(entree);
           
            //Détermination de la nature de la lettre
            switch (lettre)
            {
                case 'a':
                case 'e':
                case 'i':
                case 'o':
                case 'u':
                case 'y':
                    Console.WriteLine(lettre + " est une voyelle");
                    break;
                default: Console.WriteLine(lettre + " est une consonne");
                    break;
            }
            Console.ReadKey();
        }
    }
}