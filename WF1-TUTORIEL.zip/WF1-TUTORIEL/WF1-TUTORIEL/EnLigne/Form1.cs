﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EnLigne
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Remplir la liste des périphériques
            lstPeripherique.Items.Add("Disque Dur Externe");
            lstPeripherique.Items.Add("Souris Gaming");
            lstPeripherique.Items.Add("Imprimante");
            //Remplir la liste modifiable
            cboPaiement.Items.Add("US Dollars");
            cboPaiement.Items.Add("Chèque");
            cboPaiement.Items.Add("Euros");
        }

        private void btnQuitter_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void optPC_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void optPortable_CheckedChanged(object sender, EventArgs e)
        {
            //Tester la valeur du numéro d'index correspondant à l'élément sélectionné
            switch (gpbOrdinateur.CheckedChanged)
            {
                case 0: //le portable est sélectionné
                    //Charge l'image dans le contrôle PictureBox1
                    pictureBox5.Image = Image.FromFile("image portable");
                    break;
            }
        }
    }
}
