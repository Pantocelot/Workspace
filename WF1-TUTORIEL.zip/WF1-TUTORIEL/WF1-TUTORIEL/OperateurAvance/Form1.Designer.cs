﻿namespace OperateurAvance
{
    partial class frmOperateursAvances
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnCalculer = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.optPuissance = new System.Windows.Forms.RadioButton();
            this.optModulo = new System.Windows.Forms.RadioButton();
            this.optDivision = new System.Windows.Forms.RadioButton();
            this.lblResultat = new System.Windows.Forms.Label();
            this.txtNb2 = new System.Windows.Forms.TextBox();
            this.txtNb1 = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(423, 88);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 13);
            this.label3.TabIndex = 20;
            this.label3.Text = "Résultat";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(55, 146);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 13);
            this.label2.TabIndex = 19;
            this.label2.Text = "Variable 2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(55, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 13);
            this.label1.TabIndex = 18;
            this.label1.Text = "Variable 1";
            // 
            // btnCalculer
            // 
            this.btnCalculer.Location = new System.Drawing.Point(296, 290);
            this.btnCalculer.Name = "btnCalculer";
            this.btnCalculer.Size = new System.Drawing.Size(75, 23);
            this.btnCalculer.TabIndex = 17;
            this.btnCalculer.Text = "&Calculer";
            this.btnCalculer.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.optPuissance);
            this.groupBox1.Controls.Add(this.optModulo);
            this.groupBox1.Controls.Add(this.optDivision);
            this.groupBox1.Location = new System.Drawing.Point(187, 72);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(158, 173);
            this.groupBox1.TabIndex = 16;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Opérateur";
            // 
            // optPuissance
            // 
            this.optPuissance.AutoSize = true;
            this.optPuissance.Location = new System.Drawing.Point(15, 103);
            this.optPuissance.Name = "optPuissance";
            this.optPuissance.Size = new System.Drawing.Size(74, 17);
            this.optPuissance.TabIndex = 2;
            this.optPuissance.TabStop = true;
            this.optPuissance.Text = "Puissance";
            this.optPuissance.UseVisualStyleBackColor = true;
            // 
            // optModulo
            // 
            this.optModulo.AutoSize = true;
            this.optModulo.Location = new System.Drawing.Point(15, 72);
            this.optModulo.Name = "optModulo";
            this.optModulo.Size = new System.Drawing.Size(90, 17);
            this.optModulo.TabIndex = 1;
            this.optModulo.TabStop = true;
            this.optModulo.Text = "Modulo (Mod)";
            this.optModulo.UseVisualStyleBackColor = true;
            // 
            // optDivision
            // 
            this.optDivision.AutoSize = true;
            this.optDivision.Location = new System.Drawing.Point(15, 37);
            this.optDivision.Name = "optDivision";
            this.optDivision.Size = new System.Drawing.Size(97, 17);
            this.optDivision.TabIndex = 0;
            this.optDivision.TabStop = true;
            this.optDivision.Text = "Division entière";
            this.optDivision.UseVisualStyleBackColor = true;
            // 
            // lblResultat
            // 
            this.lblResultat.AutoSize = true;
            this.lblResultat.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblResultat.Location = new System.Drawing.Point(403, 118);
            this.lblResultat.Name = "lblResultat";
            this.lblResultat.Size = new System.Drawing.Size(2, 15);
            this.lblResultat.TabIndex = 15;
            // 
            // txtNb2
            // 
            this.txtNb2.Location = new System.Drawing.Point(56, 175);
            this.txtNb2.Name = "txtNb2";
            this.txtNb2.Size = new System.Drawing.Size(100, 20);
            this.txtNb2.TabIndex = 14;
            // 
            // txtNb1
            // 
            this.txtNb1.Location = new System.Drawing.Point(55, 99);
            this.txtNb1.Name = "txtNb1";
            this.txtNb1.Size = new System.Drawing.Size(100, 20);
            this.txtNb1.TabIndex = 13;
            // 
            // frmOperateursAvances
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(614, 388);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnCalculer);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lblResultat);
            this.Controls.Add(this.txtNb2);
            this.Controls.Add(this.txtNb1);
            this.Name = "frmOperateursAvances";
            this.Text = "Opérateurs avancés";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnCalculer;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton optPuissance;
        private System.Windows.Forms.RadioButton optModulo;
        private System.Windows.Forms.RadioButton optDivision;
        private System.Windows.Forms.Label lblResultat;
        private System.Windows.Forms.TextBox txtNb2;
        private System.Windows.Forms.TextBox txtNb1;
    }
}

