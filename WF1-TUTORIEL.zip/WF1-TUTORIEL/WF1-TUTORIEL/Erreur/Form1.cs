﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Erreur
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnTester_Click(object sender, EventArgs e)
        {
            byte Age;
            //Tester l'age saisi
            try
            {
                Age = byte.Parse(txtAge.Text);

                if ((Age > 13) && (Age < 20))
                    lblReponse.Text = "Vous êtes un adolescent.";
                else
                    lblReponse.Text = "Vous n'êtes pas un adolescent.";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txtAge_Enter(object sender, EventArgs e)
        {
            //Effacer le résidu de la zone de texte si nécessaire
            txtAge.Text = "";
        }

        private void txtAge_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Si touche ENTREE appuyée, déclencher l'action du bouton btnTester
            if(e.KeyChar == (char)Keys.Return)
            {
                btnTester_Click(sender, e);
            }

            // Contrôle de la validité du caractère saisi
            //Si le caractère est autre que numérique, il sera effacé
            if (!Char.IsDigit(e.KeyChar))
                e.Handled = true;
        }
    }
}
