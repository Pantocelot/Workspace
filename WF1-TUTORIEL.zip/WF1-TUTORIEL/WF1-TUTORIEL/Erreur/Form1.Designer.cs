﻿namespace Erreur
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblReponse = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.txtAge = new System.Windows.Forms.TextBox();
            this.btnTester = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblReponse
            // 
            this.lblReponse.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblReponse.Location = new System.Drawing.Point(164, 112);
            this.lblReponse.Name = "lblReponse";
            this.lblReponse.Size = new System.Drawing.Size(296, 32);
            this.lblReponse.TabIndex = 19;
            // 
            // Label1
            // 
            this.Label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.Location = new System.Drawing.Point(60, 48);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(144, 24);
            this.Label1.TabIndex = 18;
            this.Label1.Text = "Entrez votre âge";
            // 
            // txtAge
            // 
            this.txtAge.Location = new System.Drawing.Point(220, 48);
            this.txtAge.Name = "txtAge";
            this.txtAge.Size = new System.Drawing.Size(184, 20);
            this.txtAge.TabIndex = 17;
            this.txtAge.Enter += new System.EventHandler(this.txtAge_Enter);
            this.txtAge.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAge_KeyPress);
            // 
            // btnTester
            // 
            this.btnTester.Location = new System.Drawing.Point(260, 184);
            this.btnTester.Name = "btnTester";
            this.btnTester.Size = new System.Drawing.Size(112, 32);
            this.btnTester.TabIndex = 16;
            this.btnTester.Text = "&Tester";
            this.btnTester.Click += new System.EventHandler(this.btnTester_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(602, 308);
            this.Controls.Add(this.lblReponse);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.txtAge);
            this.Controls.Add(this.btnTester);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Label lblReponse;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.TextBox txtAge;
        internal System.Windows.Forms.Button btnTester;
    }
}

