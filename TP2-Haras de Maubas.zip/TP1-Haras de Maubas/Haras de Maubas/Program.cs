﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using LibCheval;

namespace Haras_de_Maubas
{
    class Program
    {
        static void Main(string[] args)
        {
            //Programme pour tester le bon fonctionnement de la classe

            Console.ReadKey();
        }
    }
}
