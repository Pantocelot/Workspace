﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LibCheval
{
    public class Cheval
    {
        #region attribut de la classe

        //Les attributs

        #endregion

        #region Propriétés de la classe

        //Les accesseurs ou propriétés c#

        #endregion

        #region Constructeurs

        //Déclaration des constructeurs

        #endregion

        #region Méthodes

        //Déclaration des méthodes

        #endregion
    }
}
