﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using LibCheval;

namespace Haras_de_Maubas_Form
{
    public partial class HarasDeMaubas : Form
    {
        //Déclaration des variables globales
        Cheval[] chevaux = new Cheval[10];
        int nbchevaux = 0;

        public HarasDeMaubas()
        {
            InitializeComponent();
        }
       
    }
}
