﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Exercice1
    {
        static void Main(string[] args)
        {
            //Déclaration des variables
            decimal N1, N2, N3;
            string strN1, strN2, strN3;

            //Saisie du premier nombre
            Console.Write("\nEntrez le premier nombre : ");
            strN1 = Console.ReadLine();
            N1 = decimal.Parse(strN1);

            //Saisie du second nombre
            Console.Write("\nEntrez le second nombre : ");
            strN2 = Console.ReadLine();
            N2 = decimal.Parse(strN2);

            //Affichage des variables
            Console.Write("\nVous avez saisi : ");
            Console.WriteLine(N1 + N2);

            //Exécution des calculs
            Console.Write("\nLa somme : ");
            N3 = N1 + N2;
            Console.WriteLine(N3);
            N3 = N1 - N2;
            Console.Write("\nLa différence : ");
            Console.WriteLine(N3);
            N3 = N1 * N2;
            Console.Write("\nLa produit : ");
            Console.WriteLine(N3);
            N3 = N1 / N2;
            Console.Write("\nLa division réelle : ");
            Console.WriteLine(N3);
            N3 = N1 % N2;
            Console.WriteLine("\nLa division entière : ");
            Console.WriteLine(N3);
            int n = N1;
            int d = N2;
            int q = N1 / N2;
            int r = N1 % N2;
            Console.ReadKey();
        }
    }
}
