﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Déclaration des variables
            decimal v1, v2, v3;
            string strv1, v2, v3;

            //Saisie des caractères
            Console.Write("\nDonner 2 caractères : ");
            Console.Write(v1, v2);
            Console.Write("\nVous avez saisi dans v1 = ", v1, ", dans v2 = ", v2);

            //Exécution de l'échange
            v1 = v2;
            v2 = v1;
            Console.WriteLine("\nAprès l'échange v1 = ", v1, ", v2 = ", v2);
            Console.Write(v1, v2);

            //Fin du programme
            Console.ReadKey();
        }
    }
}
